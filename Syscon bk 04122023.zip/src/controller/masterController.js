const moment = require('moment')
const validate = require('../helper/validate')
const model = require("../models/module")
const mongoose = require('mongoose')
const Schema  = require('../schema/Newschema')

module.exports = {
    // for defining the structure of master
    Add_MasterController: async (req, res) => {
        try {
            const validationRule = {
                table_name: "required"
            }
            validate(req.body, validationRule, {}, async (err, status) => {
                if (!status) {
                    res.status(403).send({
                        success: false,
                        message: "Validation Error....!",
                        data: err
                    })
                }
                else {
                    let insertData = {}
                    insertData.id = req.body.id || ""
                    insertData.table_name = req.body.table_name,
                        insertData.fields = req.body.fields
                        insertData.indexes = req.body.indexes||null

                        console.log('insertData........................................');
                        console.log(insertData);
                    if (Array.isArray(req.body.children)) {
                        insertData.children = req.body.children
                    }
                    else {
                        insertData.children = []
                    }
                    let data = await model.Update_If_Avilable_Else_Insert("master_schema", "master_schema", insertData, res)
                    data ? res.send({ success: true, message: "Data inserted successfully....", data: data }) : res.status(500).send({ success: false, message: "Data not inserted Successfully..." })
                }
            })

        } catch (error) {
            res.status(500).send({
                success: false,
                message: "Something went wrong...",
                data: error.message
            })
        }
    },

    list: async (req, res) => {
        try {
            let query = [

                { $unwind: '$fields' },
                { $match: { 'fields.status': 1 } },
                {
                    $group: {
                        _id: '$_id',
                        id: { $first: '$id' },
                        table_name: { $first: '$table_name' },
                        fields: {
                            $push: {
                                fieldname: '$fields.fieldname',
                                default_value: '$fields.default_value',
                                isrequired: '$fields.isrequired',
                                status: '$fields.status',
                            },
                        },
                        children: { $first: "$children" },
                        status: { $first: '$status' },
                        add_dt: { $first: '$add_dt' },
                        updated_dt: { $first: '$updated_dt' },
                        add_by: { $first: '$add_by' },
                        updated_by: { $first: '$updated_by' }
                    }
                }


            ]
            let result = await model.AggregateFetchData("master_schema", "master_schema", query, res)
            result.length > 0 ? res.send({ success: true, message: "Master Record fetched", data: result }) : res.status(200).send({
                success: false, message: "No data Found....!", data: []
            })
        } catch (error) {
            res.status(500).send({
                success: false,
                message: "Something went Wrong....!",
                data: error.message
            })
        }
    },

    // to Insert values in mastrers
    Create_mater: async (req, res) => {
        // TO DO
        // Check refrance id from master, Wip
        // Chek unique for combination or Single
        // creating indexs while defining schema, RND
        // Date And time data type ,Done
        // Screen Drwaing of company master
        // Diffrent database for diff users
        // validation based on formcontrol,WIP
        // validation have to check the combination of keys 
        try {
            const validationRule = {
                table_name: "required"
            }
            validate(req.body, validationRule, {}, async (err, status) => {
                if (!status) {
                    res.status(403).send({

                        success: false,
                        Message: "Validation Error...!",
                        data: err
                    }
                    )
                }
                else {
                    let query = [
                        {
                            $match: {
                                table_name: req.body.table_name
                            }
                        },
                    ]
                    let data_for_validation = await model.AggregateFetchData("master_schema", "master_schema", query, res)
                    let ValidationRules_for_tables = {}
                    data_for_validation[0].fields.map((validation) => {
                        validation.isrequired == true ? ValidationRules_for_tables[validation.fieldname] = "required" : ""
                    })
                    console.log(ValidationRules_for_tables);
                    validate(req.body, ValidationRules_for_tables, {}, async (err, status) => {
                        if (!status) {
                            res.status(403).send({
                                success: false,
                                Message: "Validation Error...!",
                                data: err
                            })
                        }
                        else {
                            let todays_dt = moment().format("YYYY-MM-DD HH:mm:ss")
                            // let insertData = {}
                            const insertData = {
                                id: req.body.id || '',
                                createdDate: todays_dt,
                                createdBy: req.body.createdBy,
                                updatedDate: todays_dt,
                                updatedBy: req.body.updatedBy,
                            };

                            data_for_validation[0].fields.forEach((field) => {
                                insertData[field.fieldname] = req.body[field.fieldname] || field.default_value;
                            });

                            data_for_validation[0].children.forEach((child) => {
                                insertData[child.table_name] = (req.body[child.table_name] || []).map((values) => {
                                    const tempObject = {id: new mongoose.Types.ObjectId() };

                                    child.fields.forEach((child_fields) => {
                                        tempObject[child_fields.fieldname] = values[child_fields.fieldname] || child_fields.default_value;
                                    });
                                    child.subChildren.forEach((subChild) => {
                                        tempObject[subChild.table_name] = (values[subChild.table_name] || []).map((values) => {
                                            const subChildObject = {id: new mongoose.Types.ObjectId() };
                                            subChild.fields.forEach((subChild_fields) => {
                                                subChildObject[subChild_fields.fieldname] = values[subChild_fields.fieldname] || subChild_fields.default_value;
                                            });
                                            return subChildObject;
                                        });
                                    })

                                    

                                    return tempObject;
                                });
                            });


                            console.log(insertData);
                            // return
                            let result = await model.Update_If_Avilable_Else_Insert(req.body.table_name, req.body.table_name, insertData,data_for_validation[0].indexes, res)
                            if (result) {
                                res.send({
                                    success: true,
                                    message: "Data inserted Successfully..!",
                                    data: result
                                })
                            }
                            else {
                                res.status(500).send({
                                    success: false,
                                    message: "Data Not Inserted Successfull....!",
                                    data: []
                                })
                            }

                        }
                    })

                }
            })
        } catch (error) {
            res.status(500).send({
                success: false,
                message: "something Went Worng...!",
                data: error.message
            })
        }
    },
    dytablelist: async (req, res) => {
        try {
            const validationRule = { table_name: "required" };
            validate(req.body, validationRule, {}, async (err, status) => {
                if (!status) {
                    return res.status(403).send({ success: false, message: "Validation Error...!", data: err });
                }
    
                // Fetch the schema for the specified table_name
                let schemaQuery = [{ $match: { table_name: req.body.table_name } }];
                let schemaResult = await model.AggregateFetchData("master_schema", "master_schema", schemaQuery, res);
    
                if (schemaResult.length === 0) {
                    return res.status(200).send({ success: false, message: "No schema found", data: [] });
                }
    
                let joinFieldName;
                let joincompany;
    
                for (let field of schemaResult[0].fields) {
                    if (field.reference_table === 'tbl_voucher_ledger') {
                        joinFieldName = field.fieldname;
                        reference_tableone = field.reference_table;

                    } else if (field.reference_table === 'tbl_company_mst') {
                        joincompany = field.fieldname;
                        reference_table = field.reference_table;
                    }
                }
    
                if (!joinFieldName || !joincompany) {
                    return res.status(200).send({ success: false, message: "No suitable join fields found", data: [] });
                }
    
                let query = [
                    { $match: {} }, // Match all documents from the table specified in req.body.table_name
                    {
                        $lookup: {
                            from: reference_tableone,
                            localField: joinFieldName,
                            foreignField: "voucher_ledger_id",
                            as: "voucher_ledger"
                        }
                    },
                    {
                        $lookup: {
                            from: reference_table,
                            localField: joincompany,
                            foreignField: "company_id",
                            as: "company_mst"
                        }
                    }
                ];
    
                let result = await model.AggregateFetchData(req.body.table_name, req.body.table_name, query, res);
                result.length > 0 ? res.send({ success: true, message: "Master Record fetched", data: result })
                                  : res.status(200).send({ success: false, message: "No data Found", data: [] });
            });
        } catch (error) {
            res.status(500).send({ success: false, message: "Something went wrong", data: error.message });
        }
    },  
}