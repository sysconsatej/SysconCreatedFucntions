const blController = require('../controller/FormControlCon');
const express=require('express');
const router=express.Router();

router.post("/Add",blController.parentChildAdd)

module.exports=router