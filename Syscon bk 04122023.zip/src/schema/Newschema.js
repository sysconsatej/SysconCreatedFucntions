const { bgYellow } = require('colors');
const mongoose = require('mongoose');

module.exports = {

  any: new mongoose.Schema({}, { strict: false }),



  mainTableSchema: new mongoose.Schema({
    id: { type: Number, required: true, default: 0 },
    table_name: {type:String, required:false, default:null},
    menuID: {type:String, required:false, default:null},
    status: {type:Number, required:false, default:1},
    // gridView: Number,

    fields: [{
      fieldname: {type:String, required:false, default:null},
      yourlabel: {type:String, required:false, default:null},
      controlname: {type:String, required:false, default:null},// Type of control like dropdown, radio , text
      isControlShow: { type: Boolean, default: true },// to show and hide the control
      // Width: Number,
      // Height: Number,
      referenceTable: {type:String, required:false, default:null},
      referenceColumn: {type:String, required:false, default:null},// have to check the combination of keys 
      type: {type:mongoose.Schema.Types.Mixed, required:false, default:null},// Data type like number, string, decimal etc,
      size: {type:Number, required:false, default:null},//size of the control to accept the values
      ordering: {type:Number, required:false, default:null},
      isRequired: { type: Boolean, default: false },
      isEditable: { type: Boolean, default: true },
      dropdownFilter: {type:String, required:false, default:null},// filter condition for child dropdown
      controlDefaultValue: {type:mongoose.Schema.Types.Mixed, required:false, default:null},
      functionOnChange: {type:String, required:false, default:null},
      functionOnBlur: {type:String, required:false, default:null},
      functionOnKeyPress: {type:String, required:false, default:null},
      sectionHeader: {type:String, required:false, default:null},// Short by this keys to drow the screem
      sectionOrder: {type:Number, required:false, default:null},// Short by this keys to drow the screem
    }],
    children: [{
      table_name: {type:String, required:false, default:null},
      fields: [{
        fieldname: {type:String, required:false, default:null},
      yourlabel: {type:String, required:false, default:null},
      controlname: {type:String, required:false, default:null},// Type of control like dropdown, radio , text
      isControlShow: { type: Boolean, default: true },// to show and hide the control
      // Width: Number,
      // Height: Number,
      referenceTable: {type:String, required:false, default:null},
      referenceColumn: {type:String, required:false, default:null},// have to check the combination of keys 
      type: {type:mongoose.Schema.Types.Mixed, required:false, default:null},// Data type like number, string, decimal etc,
      size: {type:Number, required:false, default:null},
      ordering: {type:Number, required:false, default:null},
      isRequired: { type: Boolean, default: false },
      isEditable: { type: Boolean, default: true },
      dropdownFilter: {type:String, required:false, default:null},// filter condition for child dropdown
      controlDefaultValue: {type:mongoose.Schema.Types.Mixed, required:false, default:null},
      functionOnChange: {type:String, required:false, default:null},
      functionOnBlur: {type:String, required:false, default:null},
      functionOnKeyPress: {type:String, required:false, default:null},
      sectionHeader: {type:String, required:false, default:null},// Short by this keys to drow the screem
      sectionOrder: {type:Number, required:false, default:null},// Short by this keys to drow the screem
      }],
      subChildren: [{
        table_name: {type:String, required:false, default:null},
        fields: [{
          fieldname: {type:String, required:false, default:null},
          yourlabel: {type:String, required:false, default:null},
          controlname: {type:String, required:false, default:null},// Type of control like dropdown, radio , text
          isControlShow: { type: Boolean, default: true },// to show and hide the control
          // Width: Number,
          // Height: Number,
          referenceTable: {type:String, required:false, default:null},
          referenceColumn: {type:String, required:false, default:null},// have to check the combination of keys 
          type: {type:mongoose.Schema.Types.Mixed, required:false, default:null},// Data type like number, string, decimal etc,
          size: {type:Number, required:false, default:null},
          ordering: {type:Number, required:false, default:null},
          isRequired: { type: Boolean, default: false },
          isEditable: { type: Boolean, default: true },
          dropdownFilter: {type:String, required:false, default:null},// filter condition for child dropdown
          controlDefaultValue: {type:mongoose.Schema.Types.Mixed, required:false, default:null},
          functionOnChange: {type:String, required:false, default:null},
        }]
      }]
    }], // Array of child tables

  }),// Form Control master

  master_schema: new mongoose.Schema({
    id: { type: Number, required: true, default: 0 },
    table_name: { type: String, required: false, default: null },
    fields: [{
      fieldname: String,
      default_value: mongoose.Schema.Types.Mixed,
      status: { type: Number, required: false, default: 1 },
      isrequired: Boolean,
      type: { type: String, required: false, default: null },
      size: { type: Number, required: false, default: null },
      referenceTable: { type: String, required: false, default: null },

    }],
    children: [{
      table_name: String,
      fields: [{
        fieldname: String,
        default_value: mongoose.Schema.Types.Mixed,
        status: { type: Number, required: false, default: 1 },
        isRequired: Boolean,
        type: { type: String },
        size: { type: Number },
        
      }],
      subChildren: [{
        table_name: String,
        fields: [{
          fieldname: String,
          default_value: mongoose.Schema.Types.Mixed,
          status: { type: Number, required: false, default: 1 },
          isRequired: Boolean,
          type: { type: String },
          size: { type: Number },
        }]
      }]
    }], // Array of child tables
    indexes:{},
    status: { type: Number, required: false, default: 1 },
    add_dt: { type: Date, required: false, default: Date.now() },
    updated_dt: { type: Date, required: false, default: Date.now() },
    add_by: { type: Number, required: false, default: null },
    updated_by: { type: Number, required: false, default: null },

  }),// Master Control Shema
}



